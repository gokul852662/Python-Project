import tkinter as tk
from tkinter import *
from PIL import Image, ImageTk
import cv2
import face_recognition
import numpy as np
import os

class FaceRecognitionApp:
    def __init__(self):
        self.window = tk.Tk()
        self.window.geometry("600x500")
        self.window.title("Face Recognition")
        self.window.config(bg="#02FEF2")
        self.window.resizable(0, 0)

        self.frame = Frame(self.window, width=600, height=500, bg="#02FEF2")
        self.frame.place(x=0, y=0)

        label_title = Label(self.frame, text=" Face  Detection ", font=("Gabriola", 55, "bold"), bg="#02FEF2")
        label_title.place(x=130, y=80)

        label_subtitle = Label(self.frame, text="using  face  identifier", font=("Arial Rounded MT Bold", 13), bg="#02FEF2",fg="#FE020D")
        label_subtitle.place(x=170, y=178)

        button_scan = Button(self.frame, text="Scan for Face", font=("times new roman", 12, "bold"),bg="#0228FE",fg="#FDFEFE", command=self.cam)
        button_scan.place(x=250, y=220)


        self.path = 'Images'
        self.images = []
        self.classNames = []
        self.myList = os.listdir(self.path)


        for cl in self.myList:
            curImg = cv2.imread(f'{self.path}/{cl}')
            self.images.append(curImg)
            self.classNames.append(os.path.splitext(cl)[0])
        print(self.classNames)

        self.encodeListKnown = self.findEncodings(self.images)
        print('Encoding Complete...!!!')
 

    def findEncodings(self, images):
        encodeList = []
        for img in images:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            encode = face_recognition.face_encodings(img)[0]
            encodeList.append(encode)
        return encodeList

    def cam(self):
        
        self.f2 = Frame(self.window, width=600, height=500)
        self.f2.place(x=0, y=0)

        self.label = Label(self.f2)
        self.label.place(x=0, y=0)

        self.cap = cv2.VideoCapture(0)
        self.img = None
      
        success, self.img = self.cap.read()
        imgS = cv2.resize(self.img, (0, 0), None, 0.25, 0.25)
        imgS = cv2.cvtColor(self.img, cv2.COLOR_BGR2RGB)

        facesCurFrame = face_recognition.face_locations(imgS)
        encodeCurFrame = face_recognition.face_encodings(imgS, facesCurFrame)

        for encodeFace, facloc in zip(encodeCurFrame, facesCurFrame):
            matches = face_recognition.compare_faces(self.encodeListKnown, encodeFace)
            faceDis = face_recognition.face_distance(self.encodeListKnown, encodeFace)
##            print(faceDis)
            matchIndex = np.argmin(faceDis)

            if matches[matchIndex]:
                name = self.classNames[matchIndex].upper()
                print(name)
                
        img_rgb = cv2.cvtColor(self.img, cv2.COLOR_BGR2RGB)
        img_pil = Image.fromarray(img_rgb)
        img_tk = ImageTk.PhotoImage(image=img_pil)

        self.label.config(image=img_tk)
        self.label.image = img_tk

        self.window.after(10, self.cam)  # Call the cam function after 10 milliseconds

 
if __name__ == "__main__":
    app = FaceRecognitionApp()  
